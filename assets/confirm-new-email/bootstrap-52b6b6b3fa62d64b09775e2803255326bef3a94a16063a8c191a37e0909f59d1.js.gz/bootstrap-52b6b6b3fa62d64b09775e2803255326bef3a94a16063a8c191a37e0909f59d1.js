require("confirm-new-email/confirm-new-email");
//# sourceMappingURL=/assets/confirm-new-email/bootstrap-52b6b6b3fa62d64b09775e2803255326bef3a94a16063a8c191a37e0909f59d1.js.map