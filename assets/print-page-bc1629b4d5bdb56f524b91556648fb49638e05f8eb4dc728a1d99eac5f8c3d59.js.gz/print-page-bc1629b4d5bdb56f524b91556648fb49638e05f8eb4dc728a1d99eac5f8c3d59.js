document.addEventListener("DOMContentLoaded",function(){window.print()});
//# sourceMappingURL=/assets/print-page-bc1629b4d5bdb56f524b91556648fb49638e05f8eb4dc728a1d99eac5f8c3d59.js.map