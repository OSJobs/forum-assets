window.WeakMap&&window.Promise||(window.unsupportedBrowser=!0);
//# sourceMappingURL=/assets/browser-detect-712e5d586630c3b84a07f53b0eb10ca4231ea98ea58901927d325234ead4c9b4.js.map