require("wizard/wizard").default.create().start();
//# sourceMappingURL=/assets/wizard-start-661d526af4254896b402e6a23b35b6603032ae63cd0e4446a02a4a6a62bf59b2.js.map